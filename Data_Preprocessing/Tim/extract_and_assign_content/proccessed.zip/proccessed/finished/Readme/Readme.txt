(1).Total Number of threads: 4251

(2).Failed output data:
	1. 2008-August.txt failed.
	2. 2008-July.txt failed.
	3. 2008-June.txt failed.
	4. 2014-February.txt failed.
	5. 2014-January.txt failed.
	6. 2014-September.txt failed.

(3). Functionality of each program
	1. fliter.py: extract information and assign them to proper thread
	2. subject_fix.py: fix subjects
	3. count_thread.py: count total amount of threads in all files in a directory
	

